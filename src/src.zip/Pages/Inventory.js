import React from 'react'

const inventory = () => {
    return (
        <div>inventory</div>
    )
}

export default inventory