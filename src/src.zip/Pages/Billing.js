import React from 'react'

function Billing () {
    return (
        <div id='billing'>Billing</div>
    )
}

export default Billing