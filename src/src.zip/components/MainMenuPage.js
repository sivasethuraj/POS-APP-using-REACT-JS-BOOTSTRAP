import React, { Component } from 'react';
import { Box } from "./Box";
import { Link, Route, Routes } from "react-router-dom";
import Billing from '../Pages/Billing';
import Invetory from '../Pages/Inventory';
import ItemRequest from '../Pages/ItemRequest';
import SalesReport from '../Pages/SalesReport';
import Li from './Li';

class MainMenuPage extends Component {

    state = {
        backgroundColor: 'grey',
        minHeight: '100vh',
    }


    render () {
        return (
            <div>
                <div style={ this.state }>
                    <div className="row text-center">
                        <h3>Main Menu</h3>
                    </div>


                    <Box classname="biling" content='Billing' />
                    <Box classname="inventory" content='Inventory' />
                    <Box classname="itemrequest" content='Item Request' />
                    <Box classname="salesreport" content='Sales Report' />

                </div>

                {/* <Routes>
                    <Route path='/billing' element={ Billing } />
                    <Route path='/inventory' element={ Invetory } />
                    <Route path='/itemrequest' element={ ItemRequest } />
                    <Route path='/salesreport' element={ SalesReport } />
                </Routes> */}

            </div>
        );
    }
}

export default MainMenuPage;