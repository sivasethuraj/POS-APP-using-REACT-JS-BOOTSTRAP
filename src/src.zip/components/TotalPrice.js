import React from 'react'


function TotalPrice () {
    return (
        <input
            className="form-control"
            value="Total Price Is : "
            readonly
            id="wholetotalprice"
            type="text" />
    )
}

export { TotalPrice };