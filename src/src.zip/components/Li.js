import React from 'react'

function Li ( props ) {
    return (

        <li className={ props.liclassname }>
            <a
                className={ props.aclassname }
                aria-current={ props.aria }
                onClick={ props.onclick }
                id={ props.id }>
                { props.content }
            </a>
        </li>

    )
}

export default Li