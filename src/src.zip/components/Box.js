import React from 'react';
import { Component } from "react";

class Box extends Component {
    constructor ( props ) {
        super( props )

        this.state = {
        };
    }
    render () {


        const style = {
            padding: '5rem',
            width: '25rem',
            display: 'inline-block',
            margin: '1rem',
        };

        return (
            <div className={ this.props.classname + ' bg-primary text-light' } style={ style }>

                <h1>{ this.props.content }</h1>

                {/* <button className='btn btn-danger' >  </button> */ }
            </div >
        );
    }

}
export { Box };