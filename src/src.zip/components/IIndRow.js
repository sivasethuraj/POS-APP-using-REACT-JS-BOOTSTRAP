import React from 'react'

function IIndRow () {

    return (
        <div className="row">
            <div className="col-12 col-md-5 col-sm-12 leftside-bottom" id="itemname">
                <div class="row text-center ">
                    <div class="col-3 col-md-3">
                        <label class="form-label text-primary" for="itemname">Item Name</label>
                    </div>
                    <div class="col-3 col-md-3">
                        <label class="form-label text-primary" for="itemprice">Item Price</label>
                    </div>
                    <div class="col-3 col-md-3">
                        <label class="form-label text-primary" for="itemquantity">
                            Quantity</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-3 col-md-3">
                        <input class="form-control" type="text" id="extraitemname" />
                    </div>
                    <div class="col-3 col-md-3">
                        <input class="form-control" type="number" id="itemprice" />
                    </div>
                    <div class="col-3 col-md-3">
                        <input class="form-control" type="number" id="itemquantity" />
                    </div>
                    <div class="col">
                        <button class="btn btn-primary" id="addbtn">Add</button>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-7 col-sm-12 d-flex justify-content-center align-items-center rightside-bottom">
                <button class="btn btn-primary p-4 bg-warning text-black" id="bill-btn">
                    <i class="fa-solid fa-play"></i> Bill
                </button>
            </div>
        </div>
    )
}

export { IIndRow };