import React, { useState, useEffect } from 'react'
import { Tl } from "./UpperTablePage"
function ImgTag ( props ) {

    const [ product, setProduct ] = useState( props.item )
    const { id, name, unitPrice, totalPrice } = product;

    const style = {
        height: '20vh',
        cursor: "pointer",
    };

    const setTableRows = props.setTableRows;
    const newTableRows = [];

    const handleClick = () => {

        const newProduct = {
            ...product,
            "quantity": ( product.quantity + 1 ),
            "totalPrice": ( ( product.quantity + 1 ) * product.unitPrice ),
        };
        console.log( newProduct );

        setProduct( ( prevProduct ) => {
            return {
                ...prevProduct,
                "quantity": ( prevProduct.quantity + 1 ),
                "totalPrice": ( ( prevProduct.quantity + 1 ) * prevProduct.unitPrice ),
            }
        } );
        localStorage.setItem( `${product.id}`, JSON.stringify( product ) );
        // <Tl item={ newProduct } />
        newTableRows.unshift( [
            <tr>
                <td>{ product.name }</td>
                <td>{ product.quantity }</td>
                <td>{ product.unitPrice }</td>
                <td>{ ( product.quantity * product.unitPrice ) }</td>
                <td><i className="fa-solid fa-xmark"></i></td>
            </tr> ] );

        setTableRows( newTableRows );
    }

    return (
        <>
            <img
                loading="lazy"
                style={ style }
                className={ props.classname }
                id={ id }
                src={ `../../images/${name}.jfif` }
                alt={ name }
                onClick={ handleClick }
            />
        </>
    )
}

export default ImgTag;