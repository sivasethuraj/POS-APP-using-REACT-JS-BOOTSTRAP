import React from 'react'

function salesReport () {
    return (
        <div>salesReport</div>
    )
}

export default salesReport