import React from 'react'

function Billing () {
    return (
        <div id='billing'>Hello World Billing</div>
    );
}

export default Billing